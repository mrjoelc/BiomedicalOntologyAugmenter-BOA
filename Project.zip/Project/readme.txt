producer is a microservice and need to run in a container
consumer is a microservice and need to run in a container (different from producer)
kakfa is a microservice and need to run in a container (different from producer and consumer)
all the microservice need to communicate as the standard producer consumer